class QueueUsingStacks:
    def __init__(self):
        self.s1 = []  
        self.s2 = []  

    def enqueue(self, item):
        """Insert element into queue"""
        self.s1.append(item)

    def dequeue(self):
        """Remove front element from queue"""
        if not self.s2:  
          
            while self.s1:
                self.s2.append(self.s1.pop())
        
        if not self.s2:
            raise IndexError("Queue is empty!")
        
        return self.s2.pop()

    def peek(self):
        """Get front element without removing"""
        if not self.s2:  
            while self.s1:
                self.s2.append(self.s1.pop())
        
        if not self.s2:
            raise IndexError("Queue is empty!")
        
        return self.s2[-1]

    def is_empty(self):
        return not (self.s1 or self.s2)

    def size(self):
        return len(self.s1) + len(self.s2)


# -----------------------
# Example Usage
# -----------------------
if __name__ == "__main__":
    q = QueueUsingStacks()

    q.enqueue(10)
    q.enqueue(20)
    q.enqueue(30)

    print("Front:", q.peek())   
    print("Dequeued:", q.dequeue())  
    print("Front:", q.peek())   
    print("Size:", q.size())    
    print("Is empty?", q.is_empty()) 