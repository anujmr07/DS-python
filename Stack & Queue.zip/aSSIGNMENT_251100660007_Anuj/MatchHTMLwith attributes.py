class MatchHTMLwithattributes:

    def __init__(self):
        self._data = []

    def push(self, item):
        self._data.append(item)

    def pop(self):
        if not self._data:
            raise IndexError("empty stack!!")
        return self._data.pop()

    def peek(self):
        if not self._data:
            raise IndexError("empty stack!!")
        return self._data[-1]

    def is_empty(self):
        return len(self._data) == 0


def is_html_balanced(html_content):
    stack = MatchHTMLwithattributes()
    i = 0

    while i < len(html_content):
        if html_content[i] == "<":
            j = html_content.find(">", i)

            if j == -1:
                return False  # No closing > found

            tag = html_content[i+1:j].strip()

            # CHANGE 1: Handle self-closing tags like <br/>, <img ... />, <hr />
            if tag.endswith("/"):
                i = j + 1
                continue

            # CHANGE 2: Extract only the tag name (ignore attributes)
            tag_name = tag.split()[0]   # keep only first word (tag name)

            if not tag_name.startswith("/"):
                # Opening tag → push only the tag name
                stack.push(tag_name)
            else:
                # Closing tag → match with top of stack
                top_tag = stack.pop()
                if top_tag != tag_name[1:]:  # remove '/'
                    return False
            i = j + 1
        else:
            i += 1

    return stack.is_empty()


if __name__ == "__main__":
    html_samples = [
        "<html><body><h1>Hello</h1></body></html>",                 # Balanced
        "<div><p>Test</div></p>",                                   # Not Balanced
        "<html><head></head><body><p></p></body></html>",           # Balanced
        "<html><body><h1>Title</h2></body></html>",                 # Not Balanced
        "<br/>",                                                    # Balanced (self-closing)
        "<div class='box'><p id='test'>Hello</p></div>",            # Balanced (with attributes)
        "<ul><li class='item'>A</li><li>B</li></ul>",               # Balanced
        "<div><span>Hi</div></span>",                               # Not Balanced
        "<img src='logo.png' />",                                   # Balanced (self-closing with attributes)
    ]

    for html in html_samples:
        print(f"{html}  -->  {'Balanced' if is_html_balanced(html) else 'Not Balanced'}")
