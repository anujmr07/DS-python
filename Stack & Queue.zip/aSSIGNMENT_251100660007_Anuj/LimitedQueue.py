class LimitedQueue:
    def __init__(self, capacity):
        self._data = []
        self._capacity = capacity

    def enqueue(self, item):
        if len(self._data) >= self._capacity:
            raise OverflowError(f"Queue is full! Cannot add {item}")
        self._data.append(item)

    def dequeue(self):
        if not self._data:
            raise IndexError("Queue is empty!!")
        return self._data.pop(0)   # remove from front

    def peek(self):
        if not self._data:
            raise IndexError("Queue is empty!!")
        return self._data[0]       # look at front without removing

    def is_empty(self):
        return len(self._data) == 0

    def is_full(self):
        return len(self._data) == self._capacity

    def size(self):
        return len(self._data)

    def clear(self):
        self._data.clear()

    def __str__(self):
        return f"Queue(front → rear): {self._data}"



q = LimitedQueue(3)   # queue with capacity 3

print("Empty?", q.is_empty())  # True

q.enqueue(10)
q.enqueue(20)
q.enqueue(30)
print(q)   # Queue(front → rear): [10, 20, 30]

print("Is full?", q.is_full())  # True

try:
    q.enqueue(40)  # OverflowError
except OverflowError as e:
    print("Error:", e)

print("Peek:", q.peek())     # 10
print("Dequeue:", q.dequeue())  # 10
print(q)   # Queue(front → rear): [20, 30]
print("Size:", q.size())  