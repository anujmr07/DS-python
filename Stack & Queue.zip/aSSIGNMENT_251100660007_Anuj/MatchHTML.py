class MatchHTML:

    def __init__(self):
        self._data = []

    def push(self,item):
        self._data.append(item)

    def pop(self):
        if not self._data:
            raise IndexError("empty stack!!")
        return self._data.pop()
    
    def peek(self):
        if not self._data:
            raise IndexError("empty stack!!")
        return self._data[-1]
    
    def is_empty(self):
        return len(self._data)==0


def is_html_balanced(html_content):

    stack = MatchHTML()
    i = 0

    while i< len(html_content):
        if html_content[i] =="<":
            j = html_content.find(">", i)

            if j == -1:
                return False
            
            tag = html_content[i+1:j].strip()

            if tag.endswith("/"):
                i = j+1
                continue

            if not tag.startswith("/"):
                stack.push(tag)
            else:

                top_tag = stack.pop()
                if top_tag != tag[1:]:
                    return False
            i = j+1
        else:
            i+=1

    return stack.is_empty()




if __name__ == "__main__":
    html_samples = [
        "<html><body><h1>Hello</h1></body></html>",  # Balanced
        "<div><p>Test</div></p>",                    # Not Balanced
        "<html><head></head><body><p></p></body></html>", # Balanced
        "<html><body><h1>Title</h2></body></html>", # Not Balanced
        "<br/>"                                     # Balanced (self-closing)
    ]

    for html in html_samples:
        print(f"{html}  -->  {'Balanced' if is_html_balanced(html) else 'Not Balanced'}")

