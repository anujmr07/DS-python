class ReverseContent:

    def __init__(self):
        self._data =[]

    def push(self, item):
        self._data.append(item)

    def pop(self):
        if not self._data:
            raise IndexError("Stack is empty!!")
        return self._data.pop()

    def is_empty(self):
        return(len(self._data)==0)
    

def reverse_file(input_file):

    stack =ReverseContent()


    # read from the file and push into stack

    with open(input_file, 'r') as f:
        for lines in f:
            stack.push(lines.rstrip("\n"))

    while not stack.is_empty():
        print(stack.pop())

reverse_file("input_file.txt")