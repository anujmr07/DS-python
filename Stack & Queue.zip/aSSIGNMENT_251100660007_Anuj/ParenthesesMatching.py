class ParenthesesMatching:

    def __init__(self):
        self._data = []

    def push (self, item):
        self._data.append(item)

    def pop(self):
        if not self._data:
            raise IndexError("Stack is empty!!")
        return self._data.pop()
    
    def is_empty(self):
        return len(self._data)==0
    

    def peek(self):
        if not self._data:
            raise IndexError("Stack is empty!!")
        return self._data[-1]
    


def is_balanced(expression):

    stack = ParenthesesMatching()

    open_bracket ="([{"
    close_bracket = ")]}"
    maches = {")":"(","]":"[","}":"{"}

    for ch in expression:
        if ch in open_bracket:
            stack.push(ch)
        elif ch in close_bracket:
            if stack.is_empty():
                return False
            top = stack.pop()
            if top != maches[ch]:
                return False
    return stack.is_empty()


tests = [
        "(a+b) * [c-d]",    # Balanced
        "((a+b)",           # Not balanced
        "{[()()]}",         # Balanced
        "{[(])}",           # Not balanced
        ""                  # Balanced (empty string)
    ]

for expr in tests:
    print(f"{expr}  -->  {'Balanced' if is_balanced(expr) else 'Not Balanced'}")
