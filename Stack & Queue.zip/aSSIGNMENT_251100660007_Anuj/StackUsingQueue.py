from queue import Queue

class StackUsingQueues:
    def __init__(self):
        self.q1 = Queue()  
        self.q2 = Queue()  

    def push(self, item):
        """Push element onto stack"""
       
        self.q2.put(item)

        while not self.q1.empty():
            self.q2.put(self.q1.get())

        self.q1, self.q2 = self.q2, self.q1

    def pop(self):
        """Remove top element from stack"""
        if self.q1.empty():
            raise IndexError("Stack is empty!")
        return self.q1.get()

    def top(self):
        """Return top element without removing"""
        if self.q1.empty():
            raise IndexError("Stack is empty!")
        return self.q1.queue[0]   

    def is_empty(self):
        return self.q1.empty()

    def size(self):
        return self.q1.qsize()


# -----------------------
# Example Usage
# -----------------------
if __name__ == "__main__":
    s = StackUsingQueues()

    s.push(10)
    s.push(20)
    s.push(30)

    print("Top:", s.top())
    print("Popped:", s.pop())
    print("Top:", s.top())
    print("Size:", s.size())
