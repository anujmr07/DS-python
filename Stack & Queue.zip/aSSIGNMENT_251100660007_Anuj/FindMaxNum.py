class FindMaxNum:
    def __init__(self):
        self.data = []   

    def enqueue(self, item):
        """Insert at rear"""
        self.data.append(item)

    def dequeue(self):
        """Remove from front"""
        if self.is_empty():
            raise IndexError("Queue is empty!")
        return self.data.pop(0)

    def is_empty(self):
        return len(self.data) == 0

    def size(self):
        return len(self.data)

    def display(self):
        print("Queue (front → rear):", self.data)

    def findMax(self):
        """Return maximum element without altering queue"""
        if self.is_empty():
            raise IndexError("Queue is empty!")

        max_val = self.data[0]      
        n = self.size()

        for i in range(n):
            item = self.dequeue()   
            if item > max_val:
                max_val = item
            self.enqueue(item)      

        return max_val


# -----------------------
# Example Usage
# -----------------------
if __name__ == "__main__":
    q = FindMaxNum()
    q.enqueue(15)
    q.enqueue(7)
    q.enqueue(23)
    q.enqueue(9)

    q.display()                         
    print("Maximum:", q.findMax())      
    q.display()                         
