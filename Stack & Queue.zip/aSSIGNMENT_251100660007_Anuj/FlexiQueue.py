class FlexiQueue:
    def __init__(self, capacity=2):
        
        self._data = [None] * capacity   
        self._capacity = capacity        
        self._size = 0                   
        self._front = 0                  

    def _resize(self, new_capacity):
        """Resize internal array to new_capacity"""
        new_data = [None] * new_capacity
        for i in range(self._size):
            
            new_data[i] = self._data[(self._front + i) % self._capacity]
        self._data = new_data
        self._capacity = new_capacity
        self._front = 0   

    def enqueue(self, item):
        """Add element at rear"""
        if self._size == self._capacity:   
            self._resize(2 * self._capacity)

        avail = (self._front + self._size) % self._capacity
        self._data[avail] = item
        self._size += 1

    def dequeue(self):
        """Remove element from front"""
        if self.is_empty():
            raise IndexError("Queue is empty!")

        item = self._data[self._front]
        self._data[self._front] = None   
        self._front = (self._front + 1) % self._capacity
        self._size -= 1

        
        if 0 < self._size <= self._capacity // 4:
            self._resize(max(2, self._capacity // 2))  

        return item

    def peek(self):
        """Return front element without removing"""
        if self.is_empty():
            raise IndexError("Queue is empty!")
        return self._data[self._front]

    def is_empty(self):
        """Check if queue is empty"""
        return self._size == 0

    def size(self):
        """Return current size"""
        return self._size

    def capacity(self):
        """Return current capacity"""
        return self._capacity

    def display(self):
        """Print queue contents from front → rear"""
        items = []
        for i in range(self._size):
            items.append(self._data[(self._front + i) % self._capacity])
        print("Queue (front → rear):", items, f"(capacity={self._capacity})")


# -----------------------
# Example Usage
# -----------------------
if __name__ == "__main__":
    q = FlexiQueue()

    
    q.enqueue(10)
    q.enqueue(20)
    q.display()

    q.enqueue(30)   
    q.display()

    print("Dequeued:", q.dequeue())
    q.display()

    q.enqueue(40)
    q.enqueue(50)
    q.display()

    print("Dequeued:", q.dequeue())
    print("Dequeued:", q.dequeue())
    q.display()     
