class Transfer:
    def __init__(self):
        self._data = []

    def push(self, item):
        self._data.append(item)

    def pop(self):
        if not self._data:
            raise IndexError("empty stack!!")
        return self._data.pop()
    
    def peek(self):
        if not self._data:
            raise IndexError("empty stack!!")
        return self._data[-1]
    
    def is_empty(self):
        return len(self._data) == 0
    

    def __repr__(self):
        return f"Stack(top-> bottom): {list(reversed(self._data))}"
    

def transfer_ele(S, T):

    temp = Transfer()

    while not S.is_empty():
        temp.push(S.pop())

    while not temp.is_empty():
        T.push(temp.pop())


# ------------------------------------------------------------
# Example usage
# ------------------------------------------------------------
if __name__ == "__main__":
    S = Transfer()
    T = Transfer()

    # Fill source stack S
    for i in [10, 20, 30, 40]:
        S.push(i)

    print("Before transfer:")
    print("S =", S)
    print("T =", T)

    transfer_ele(S, T)

    print("\nAfter transfer:")
    print("S =", S)  # Should be empty
    print("T =", T)  # Should contain [40, 30, 20, 10] with same top as S

