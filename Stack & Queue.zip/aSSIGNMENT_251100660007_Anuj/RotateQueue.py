class RotateQueue:
    def __init__(self):
        self.data = []   

    def enqueue(self, item):
        """Insert element at rear"""
        self.data.append(item)

    def dequeue(self):
        """Remove element from front"""
        if self.is_empty():
            raise IndexError("Queue is empty!")
        return self.data.pop(0)

    def is_empty(self):
        return len(self.data) == 0

    def size(self):
        return len(self.data)

    def display(self):
        print("Queue (front → rear):", self.data)

    def rotate(self):
        """Reverse all elements of the queue"""
        self.data.reverse()   


# -----------------------
# Example Usage
# -----------------------
if __name__ == "__main__":
    q = RotateQueue()
    q.enqueue(10)
    q.enqueue(20)
    q.enqueue(30)
    q.enqueue(40)

    q.display()   

    q.rotate()   
    q.display()   
