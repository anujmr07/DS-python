class LimitedStack:

    def __init__(self, capacity):
        self._data =[]
        self._capacity = capacity


    def push(self, item):
        if len(self._data)>= self._capacity:
            raise OverflowError(f"Stack is full can't add the element {item} !!")
        self._data.append(item)

    def pop(self):
        if not self._data:
            raise IndexError("Stack is empty!!")
        return self._data.pop()
    
    def peek(self):
        if not self._data:
            raise IndexError("Stack is empty!!")
        return self._data[-1]
    
    def is_empty(self):
        return len(self._data)==0
    
    def clear(self):
        self._data.clear()

    def is_full(self):
        return len(self._data) == self._capacity
    
    def size(self):
        return len(self._data)
    

    

stack = LimitedStack(3)  # Stack can hold at most 3 items
print("Empty?", stack.is_empty())  # True

stack.push(10)
stack.push(20)
stack.push(30)


print("Is full?", stack.is_full())  # True

try:
    stack.push(40)  # This should raise OverflowError
except OverflowError as e:
    print("Error:", e)

    print("Peek:", stack.peek())   # Look at top → 30
    print("Pop:", stack.pop())     # Remove top → 30
    print(stack)                   # LimitedStack(top → bottom): [20, 10]

    print("Size:", stack.size())   # 2
    print("Is empty?", stack.is_empty())  # False