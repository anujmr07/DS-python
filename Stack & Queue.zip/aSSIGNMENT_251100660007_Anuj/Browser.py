class Browser:
    def __init__(self):
        self._data = []

    def push(self, item):
        self._data.append(item)

    def pop(self):
        if not self._data:
            raise IndexError("empty stack!!")
        return self._data.pop()
    
    def is_empty(self):
        return len(self._data)==0
    
    def peek(self):
        if not self._data:
            raise IndexError("empty stack!!")
        return self._data[-1]
    
    def __repr__(self):
        return f"{list(self._data)}"
    

class BrowserHistory:

    def __init__(self, homepage):
        self.back_stack = Browser()
        self.forward_stack = Browser()
        self.current_page = homepage    


    def visit(self,url):
        self.back_stack.push(self.current_page)
        self.current_page = url
        self.forward_stack = Browser()

    def back(self):
        if self.back_stack.is_empty():
            print("No back history!!")
            return self.current_page
        self.forward_stack.push(self.current_page)
        self.current_page = self.back_stack.pop()
        return self.current_page

    def forward(self):
        if self.forward_stack.is_empty():
            print("No forward history!!")
            return self.current_page
        self.back_stack.push(self.current_page)
        self.current_page = self.forward_stack.pop()
        return self.current_page

    def show(self):
        print("Back Stack:", self.back_stack)
        print("Current Page:", self.current_page)
        print("Forward Stack:", self.forward_stack)


# ------------------------------------------------------------
# Example usage
# ------------------------------------------------------------
if __name__ == "__main__":
    browser = BrowserHistory("homepage.com")

    browser.visit("google.com")
    browser.visit("github.com")
    browser.visit("stackoverflow.com")
    browser.show()

    print("\nBack:", browser.back())  # Goes back to github.com
    browser.show()

    print("\nBack:", browser.back())  # Goes back to google.com
    browser.show()

    print("\nForward:", browser.forward())  # Goes forward to github.com
    browser.show()

    print("\nVisit new page:")
    browser.visit("openai.com")  # Clears forward history
    browser.show()