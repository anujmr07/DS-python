class BSTNode:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

class BST:
    def __init__(self):
        self.root = None

    def is_empty(self):
        return self.root is None

    def _count_nodes(self, node):
        if node is None:
            return 0
        return 1 + self._count_nodes(node.left) + self._count_nodes(node.right)

    def count_nodes(self):
        return self._count_nodes(self.root)

    def add(self, value):
        if self.root is None:
            self.root = BSTNode(value)
            return
        cur = self.root
        while True:
            if value < cur.data:
                if cur.left is None:
                    cur.left = BSTNode(value)
                    return
                cur = cur.left
            else:
                if cur.right is None:
                    cur.right = BSTNode(value)
                    return
                cur = cur.right

    def _search(self, node, value):
        if node is None:
            return False
        if value == node.data:
            return True
        if value < node.data:
            return self._search(node.left, value)
        return self._search(node.right, value)

    def search(self, value):
        return self._search(self.root, value)

    def _inorder(self, node, out):
        if node is None:
            return
        self._inorder(node.left, out)
        out.append(node.data)
        self._inorder(node.right, out)

    def inorder(self):
        out = []
        self._inorder(self.root, out)
        return out

    def _preorder(self, node, out):
        if node is None:
            return
        out.append(node.data)
        self._preorder(node.left, out)
        self._preorder(node.right, out)

    def preorder(self):
        out = []
        self._preorder(self.root, out)
        return out

    def _postorder(self, node, out):
        if node is None:
            return
        self._postorder(node.left, out)
        self._postorder(node.right, out)
        out.append(node.data)

    def postorder(self):
        out = []
        self._postorder(self.root, out)
        return out

    def level_order(self):
        out = []
        if self.root is None:
            return out
        from collections import deque
        q = deque([self.root])
        while q:
            node = q.popleft()
            out.append(node.data)
            if node.left:
                q.append(node.left)
            if node.right:
                q.append(node.right)
        return out

    def _find_min(self, node):
        cur = node
        while cur.left:
            cur = cur.left
        return cur

    def _delete_node(self, node, value):
        if node is None:
            return None
        if value < node.data:
            node.left = self._delete_node(node.left, value)
            return node
        if value > node.data:
            node.right = self._delete_node(node.right, value)
            return node
        # node.data == value
        if node.left is None:
            return node.right
        if node.right is None:
            return node.left
        successor = self._find_min(node.right)
        node.data = successor.data
        node.right = self._delete_node(node.right, successor.data)
        return node

    def delete(self, value):
        self.root = self._delete_node(self.root, value)

    def _height(self, node):
        if node is None:
            return 0
        return 1 + max(self._height(node.left), self._height(node.right))

    def height(self):
        return self._height(self.root)

    def _count_leaves(self, node):
        if node is None:
            return 0
        if node.left is None and node.right is None:
            return 1
        return self._count_leaves(node.left) + self._count_leaves(node.right)

    def count_terminal_nodes(self):
        return self._count_leaves(self.root)

if __name__ == "__main__":
    bst = BST()
    for v in [50, 30, 70, 20, 40, 60, 80]:
        bst.add(v)

    print("Empty:", bst.is_empty())
    print("Count:", bst.count_nodes())
    print("Search 40:", bst.search(40))
    print("Search 99:", bst.search(99))
    print("In-order:", bst.inorder())
    print("Pre-order:", bst.preorder())
    print("Post-order:", bst.postorder())
    print("Level-order:", bst.level_order())
    print("Height:", bst.height())
    print("Terminal nodes (leaves):", bst.count_terminal_nodes())

    bst.delete(70)
    print("After deleting 70, In-order:", bst.inorder())
    bst.delete(50)
    print("After deleting 50 (root), In-order:", bst.inorder())
    print("Count after deletions:", bst.count_nodes())
    print("Height after deletions:", bst.height())
    print("Leaves after deletions:", bst.count_terminal_nodes())
