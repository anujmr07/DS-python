class BSTNode:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None
        self.size = 1

class BST:
    def __init__(self):
        self.root = None

    def _size(self, node):
        return node.size if node else 0

    def is_empty(self):
        return self.root is None

    def count_nodes(self):
        return self._size(self.root)

    def _insert(self, node, value):
        if node is None:
            return BSTNode(value)
        if value < node.data:
            node.left = self._insert(node.left, value)
        elif value > node.data:
            node.right = self._insert(node.right, value)
        else:
            return node
        node.size = 1 + self._size(node.left) + self._size(node.right)
        return node

    def add(self, value):
        self.root = self._insert(self.root, value)

    def _search(self, node, value):
        if node is None:
            return False
        if value == node.data:
            return True
        if value < node.data:
            return self._search(node.left, value)
        return self._search(node.right, value)

    def search(self, value):
        return self._search(self.root, value)

    def _find_min(self, node):
        cur = node
        while cur and cur.left:
            cur = cur.left
        return cur

    def _delete(self, node, value):
        if node is None:
            return None
        if value < node.data:
            node.left = self._delete(node.left, value)
        elif value > node.data:
            node.right = self._delete(node.right, value)
        else:
            if node.left is None:
                return node.right
            if node.right is None:
                return node.left
            succ = self._find_min(node.right)
            node.data = succ.data
            node.right = self._delete(node.right, succ.data)
        node.size = 1 + self._size(node.left) + self._size(node.right)
        return node

    def delete(self, value):
        self.root = self._delete(self.root, value)

    def _inorder(self, node, out):
        if node is None:
            return
        self._inorder(node.left, out)
        out.append(node.data)
        self._inorder(node.right, out)

    def inorder(self):
        out = []
        self._inorder(self.root, out)
        return out

    def inorder_with_sizes(self):
        out = []
        def _rec(n):
            if not n:
                return
            _rec(n.left)
            out.append((n.data, n.size))
            _rec(n.right)
        _rec(self.root)
        return out

    def height(self):
        def _h(n):
            if n is None:
                return 0
            return 1 + max(_h(n.left), _h(n.right))
        return _h(self.root)

    def _select(self, node, k):
        if node is None:
            return None
        left_size = self._size(node.left)
        if k == left_size + 1:
            return node
        if k <= left_size:
            return self._select(node.left, k)
        return self._select(node.right, k - left_size - 1)

    def select(self, k):
        if k < 1 or k > self.count_nodes():
            return None
        node = self._select(self.root, k)
        return node.data if node else None

    def rank(self, value):
        node = self.root
        rank = 0
        while node:
            if value <= node.data:
                node = node.left
            else:
                rank += 1 + self._size(node.left)
                node = node.right
        return rank

if __name__ == "__main__":
    bst = BST()
    for v in [50, 30, 70, 20, 40, 60, 80]:
        bst.add(v)

    print("Empty:", bst.is_empty())
    print("Count (root.size):", bst.count_nodes())
    print("In-order:", bst.inorder())
    print("In-order with sizes:", bst.inorder_with_sizes())
    print("Search 40:", bst.search(40))
    print("Select 3 (3rd smallest):", bst.select(3))
    print("Rank of 60 (number < 60):", bst.rank(60))
    bst.delete(70)
    print("After deleting 70, inorder with sizes:", bst.inorder_with_sizes())
    bst.delete(50)
    print("After deleting 50 (root), inorder with sizes:", bst.inorder_with_sizes())
    print("Count after deletions:", bst.count_nodes())
    print("Height:", bst.height())
