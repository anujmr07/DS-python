from datetime import datetime, date, time, timedelta
from collections import deque

class EventNode:
    def __init__(self, start_dt: datetime, duration_hours: float, name: str, guests: int):
        self.start = start_dt
        self.duration = float(duration_hours)
        self.name = name
        self.guests = int(guests)
        self.left = None
        self.right = None

    def end(self) -> datetime:
        return self.start + timedelta(hours=self.duration)

class EventBST:
    def __init__(self):
        self.root = None
        self.MAX_EVENTS_PER_DAY = 2
        self.MAX_DURATION_HOURS = 5.0
        self.MIN_GAP_HOURS = 3.0

    def is_empty(self):
        return self.root is None

    def _insert(self, node: EventNode, new_node: EventNode):
        if node is None:
            return new_node
        if new_node.start < node.start:
            node.left = self._insert(node.left, new_node)
        elif new_node.start > node.start:
            node.right = self._insert(node.right, new_node)
        else:
            raise ValueError("Event at this date and time already exists")
        return node

    def add_event(self, start_dt: datetime, duration_hours: float, name: str, guests: int):
        if duration_hours <= 0 or duration_hours > self.MAX_DURATION_HOURS:
            raise ValueError(f"Duration must be >0 and <= {self.MAX_DURATION_HOURS} hours")
        new_node = EventNode(start_dt, duration_hours, name, guests)
        day_start = datetime.combine(start_dt.date(), time.min)
        day_end = datetime.combine(start_dt.date(), time.max)
        same_day = []
        self._range_search(self.root, day_start, day_end, same_day)
        if len(same_day) >= self.MAX_EVENTS_PER_DAY:
            raise ValueError("Maximum events for this day reached")
        for n in same_day:
            existing_start = n.start
            existing_end = n.end()
            new_start = new_node.start
            new_end = new_node.end()
            if new_start < existing_end and new_end > existing_start:
                raise ValueError("New event overlaps with an existing event")
            if new_end <= existing_start:
                gap = (existing_start - new_end).total_seconds() / 3600.0
                if gap < self.MIN_GAP_HOURS:
                    raise ValueError("Insufficient gap between events (less than minimum required)")
            elif new_start >= existing_end:
                gap = (new_start - existing_end).total_seconds() / 3600.0
                if gap < self.MIN_GAP_HOURS:
                    raise ValueError("Insufficient gap between events (less than minimum required)")
        self.root = self._insert(self.root, new_node)

    def _range_search(self, node, low: datetime, high: datetime, acc):
        if node is None:
            return
        if node.start > low:
            self._range_search(node.left, low, high, acc)
        if low <= node.start <= high:
            acc.append(node)
        if node.start < high:
            self._range_search(node.right, low, high, acc)

    def _find_min(self, node):
        cur = node
        while cur.left:
            cur = cur.left
        return cur

    def _delete_node(self, node, key: datetime):
        if node is None:
            return None
        if key < node.start:
            node.left = self._delete_node(node.left, key)
            return node
        if key > node.start:
            node.right = self._delete_node(node.right, key)
            return node
        # key == node.start
        if node.left is None:
            return node.right
        if node.right is None:
            return node.left
        succ = self._find_min(node.right)
        node.start = succ.start
        node.duration = succ.duration
        node.name = succ.name
        node.guests = succ.guests
        node.right = self._delete_node(node.right, succ.start)
        return node

    def cancel_event(self, start_dt: datetime):
        if self.search(start_dt) is False:
            raise ValueError("No event found at given date/time to cancel")
        self.root = self._delete_node(self.root, start_dt)

    def search(self, start_dt: datetime):
        cur = self.root
        while cur:
            if start_dt < cur.start:
                cur = cur.left
            elif start_dt > cur.start:
                cur = cur.right
            else:
                return True
        return False

    def _reverse_inorder(self, node, acc):
        if node is None:
            return
        self._reverse_inorder(node.right, acc)
        acc.append((node.start, node.duration, node.name, node.guests))
        self._reverse_inorder(node.left, acc)

    def events_descending(self):
        out = []
        self._reverse_inorder(self.root, out)
        return out

    def delete_completed(self, now: datetime = None):
        if now is None:
            now = datetime.now()
        to_delete = []
        self._collect_completed(self.root, now, to_delete)
        for k in to_delete:
            self.root = self._delete_node(self.root, k)

    def _collect_completed(self, node, now: datetime, acc):
        if node is None:
            return
        self._collect_completed(node.left, now, acc)
        if node.end() <= now:
            acc.append(node.start)
        self._collect_completed(node.right, now, acc)

    def count_nodes(self):
        return self._count_nodes(self.root)

    def _count_nodes(self, node):
        if node is None:
            return 0
        return 1 + self._count_nodes(node.left) + self._count_nodes(node.right)

    def level_order(self):
        out = []
        if self.root is None:
            return out
        q = deque([self.root])
        while q:
            n = q.popleft()
            out.append((n.start, n.duration, n.name, n.guests))
            if n.left:
                q.append(n.left)
            if n.right:
                q.append(n.right)
        return out

if __name__ == "__main__":
    bst = EventBST()

    bst.add_event(datetime(2025, 9, 20, 9, 0), 3, "Morning Meeting", 10)
    bst.add_event(datetime(2025, 9, 20, 15, 0), 2, "Afternoon Workshop", 25)
    try:
        bst.add_event(datetime(2025, 9, 20, 20, 0), 2, "Evening Talk", 30)
    except ValueError as e:
        print("Failed to add third event on same day:", e)

    try:
        bst.add_event(datetime(2025, 9, 21, 10, 0), 6, "Too Long Event", 5)
    except ValueError as e:
        print("Failed to add overlong event:", e)

    try:
        bst.add_event(datetime(2025, 9, 20, 12, 30), 1.5, "Clash Event", 8)
    except ValueError as e:
        print("Failed due to insufficient gap or overlap:", e)

    print("Events descending:")
    for ev in bst.events_descending():
        print(ev)

    bst.delete_completed(datetime(2025, 9, 21, 0, 0))
    print("After deleting completed up to 2025-09-21:")
    for ev in bst.events_descending():
        print(ev)

    start_to_cancel = datetime(2025, 9, 20, 9, 0)
    bst.cancel_event(start_to_cancel)
    print("After cancelling 2025-09-20 09:00:")
    for ev in bst.events_descending():
        print(ev)
