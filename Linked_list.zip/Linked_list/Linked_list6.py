class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def add_at_tail(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        cur = self.head
        while cur.next is not None:
            cur = cur.next
        cur.next = new_node

    def display(self):
        out = []
        cur = self.head
        while cur is not None:
            out.append(cur.data)
            cur = cur.next
        return out

    def is_palindrome(self):
        if self.head is None or self.head.next is None:
            return True
        prev_slow = None
        slow = self.head
        fast = self.head
        while fast is not None and fast.next is not None:
            prev_slow = slow
            slow = slow.next
            fast = fast.next.next
        if fast is not None:
            second = slow.next
        else:
            second = slow
        prev = None
        cur = second
        while cur is not None:
            nxt = cur.next
            cur.next = prev
            prev = cur
            cur = nxt
        p1 = self.head
        p2 = prev
        res = True
        while p2 is not None:
            if p1.data != p2.data:
                res = False
                break
            p1 = p1.next
            p2 = p2.next
        cur = prev
        prev2 = None
        while cur is not None:
            nxt = cur.next
            cur.next = prev2
            prev2 = cur
            cur = nxt
        if fast is not None:
            slow.next = prev2
        else:
            prev_slow.next = prev2
        return res

if __name__ == "__main__":
    s = SinglyLinkedList()
    for v in [1, 2, 3, 2, 1]:
        s.add_at_tail(v)
    print(s.display())
    print(s.is_palindrome())  # True

    t = SinglyLinkedList()
    for v in [1, 2, 3, 4]:
        t.add_at_tail(v)
    print(t.display())
    print(t.is_palindrome())  # False
