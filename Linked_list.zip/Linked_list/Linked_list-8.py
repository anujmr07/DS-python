class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def add_at_tail(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        cur = self.head
        while cur.next is not None:
            cur = cur.next
        cur.next = new_node

    def display(self):
        out = []
        cur = self.head
        while cur is not None:
            out.append(cur.data)
            cur = cur.next
        return out

    def find_middle(self):
        if self.head is None:
            return None
        slow = self.head
        fast = self.head
        while fast is not None and fast.next is not None:
            slow = slow.next
            fast = fast.next.next
        return slow.data

    def find_middle_first(self):
        if self.head is None:
            return None
        slow = self.head
        fast = self.head.next
        while fast is not None and fast.next is not None:
            slow = slow.next
            fast = fast.next.next
        return slow.data

if __name__ == "__main__":
    s = SinglyLinkedList()
    for v in [1,2,3,4,5]:
        s.add_at_tail(v)
    print("List:", s.display())                # [1,2,3,4,5]
    print("Middle (second on even):", s.find_middle())      # 3
    print("Middle (first on even):", s.find_middle_first()) # 3

    t = SinglyLinkedList()
    for v in [1,2,3,4]:
        t.add_at_tail(v)
    print("List:", t.display())                # [1,2,3,4]
    print("Middle (second on even):", t.find_middle())      # 3
    print("Middle (first on even):", t.find_middle_first()) # 2
