class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class Linked_list:
    def __init__(self):
        self.head = None

    def is_empty(self):
        return self.head is None
    
    def add_at_head(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

    def add_to_tail(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        cur = self.head
        while cur.next is not None:
            cur = cur.next
        cur.next = new_node

    def delete_at_head(self):
        if self.head is None:
            raise IndexError("List is empty!!")
        deleted_data = self.head.data
        self.head = self.head.next
        return deleted_data
    
    def delete_at_tail(self):
        if self.head is None:
            raise IndexError("List is empty!!")
        if self.head.next is None:
            deleated_data = self.head.data
            self.head = None
            return deleated_data
        
        prev = None
        cur = self.head

        while cur.next is not None:
            prev = cur
            cur = cur.next
        prev.next = None
        return cur.data
    
    def add_after(self, target_data, new_data):
        cur = self.head

        while cur is not None and cur.data !=target_data:
            cur = cur.next
        if cur is None:
            raise ValueError(f'{target_data} not found!!')
        
        new_node = Node(new_data)
        new_node.next = cur.next
        cur.next = new_node

    def delete_after(self, target_data):
        cur = self.head

        while cur is not None and cur.data != target_data:
            cur = cur.next
        if cur is None:
            raise ValueError(f'{target_data} is not found in the list!!')
        if cur.next is None:
            raise IndexError(f'{target_data} is the last node !!')
        deleted_data = cur.next.data
        cur.next = cur.next.next
        return deleted_data
    
    def search(self, key):
        cur = self.head
        while cur is not None:
            if cur.data == key:
                return True
            cur = cur.next
        return False
    
          
    def display(self):
        elements = []
        cur = self.head
        while cur is not None:
            elements.append(cur.data)
            cur = cur.next
        return elements
    

lst = Linked_list() # instantiate 


# Add elements at head and tail and show the list after each operation.
lst.add_at_head(10) # list: 10
lst.add_at_head(5) # list: 5 -> 10
lst.add_to_tail(15) # list: 5 -> 10 -> 15
print('After inserts:', lst.display()) # prints the current list as a Python list


# Search for elements.
print('Search 10:', lst.search(10)) # True because 10 is in the list
print('Search 99:', lst.search(99)) # False because 99 is not in the list


# Add after a node that has data 10.
lst.add_after(10, 12) # list: 5 -> 10 -> 12 -> 15
print('After add_after 10 -> 12:', lst.display())


# Delete after a node that has data 10.
deleted = lst.delete_after(10) # deletes 12; returns its value
print('Deleted after 10:', deleted)
print('After delete_after:', lst.display()) # list: 5 -> 10 -> 15


# Delete at head and tail.
head_deleted = lst.delete_at_head() # removes 5
tail_deleted = lst.delete_at_tail() # removes 15
print('Deleted head:', head_deleted)
print('Deleted tail:', tail_deleted)
print('Final list:', lst.display()) # list: 10


        

