class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def add_at_tail(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        cur = self.head
        while cur.next is not None:
            cur = cur.next
        cur.next = new_node

    def display(self):
        out = []
        cur = self.head
        while cur is not None:
            out.append(cur.data)
            cur = cur.next
        return out

    def remove_duplicates(self):
        seen = set()
        prev = None
        cur = self.head
        while cur is not None:
            if cur.data in seen:
                prev.next = cur.next
            else:
                seen.add(cur.data)
                prev = cur
            cur = cur.next

    def remove_duplicates_no_buffer(self):
        cur = self.head
        while cur is not None:
            runner = cur
            while runner.next is not None:
                if runner.next.data == cur.data:
                    runner.next = runner.next.next
                else:
                    runner = runner.next
            cur = cur.next

if __name__ == "__main__":
    s = SinglyLinkedList()
    for v in [3, 5, 3, 2, 5, 1, 2]:
        s.add_at_tail(v)
    print("Before:", s.display())
    s.remove_duplicates()
    print("After (O(n) method):", s.display())

    t = SinglyLinkedList()
    for v in [3, 5, 3, 2, 5, 1, 2]:
        t.add_at_tail(v)
    t.remove_duplicates_no_buffer()
    print("After (O(n^2) no-buffer):", t.display())
