class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def is_empty(self):
        return self.head is None

    def add_at_head(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

    def add_at_tail(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        cur = self.head
        while cur.next is not None:
            cur = cur.next
        cur.next = new_node

    def delete_at_head(self):
        if self.head is None:
            raise IndexError('delete_at_head from empty list')
        deleted_data = self.head.data
        self.head = self.head.next
        return deleted_data

    def delete_at_tail(self):
        if self.head is None:
            raise IndexError('delete_at_tail from empty list')
        if self.head.next is None:
            deleted_data = self.head.data
            self.head = None
            return deleted_data
        prev = None
        cur = self.head
        while cur.next is not None:
            prev = cur
            cur = cur.next
        prev.next = None
        return cur.data

    def add_after(self, target_data, new_data):
        cur = self.head
        while cur is not None and cur.data != target_data:
            cur = cur.next
        if cur is None:
            raise ValueError(f'{target_data} not found in list')
        new_node = Node(new_data)
        new_node.next = cur.next
        cur.next = new_node

    def delete_after(self, target_data):
        cur = self.head
        while cur is not None and cur.data != target_data:
            cur = cur.next
        if cur is None:
            raise ValueError(f'{target_data} not found in list')
        if cur.next is None:
            raise IndexError(f'No node exists after {target_data} to delete')
        deleted_data = cur.next.data
        cur.next = cur.next.next
        return deleted_data

    def search(self, key):
        cur = self.head
        while cur is not None:
            if cur.data == key:
                return True
            cur = cur.next
        return False

    def display(self):
        elements = []
        cur = self.head
        while cur is not None:
            elements.append(cur.data)
            cur = cur.next
        return elements

def reverse_iterative(sll):
    prev = None
    cur = sll.head
    while cur is not None:
        next_node = cur.next
        cur.next = prev
        prev = cur
        cur = next_node
    sll.head = prev

def reverse_recursive(sll):
    def _reverse(node, prev=None):
        if node is None:
            return prev
        next_node = node.next
        node.next = prev
        return _reverse(next_node, node)
    sll.head = _reverse(sll.head)

if __name__ == '__main__':
    lst = SinglyLinkedList()
    lst.add_at_head(10)
    lst.add_at_head(5)
    lst.add_at_tail(15)
    print('After inserts:', lst.display())
    print('Search 10:', lst.search(10))
    print('Search 99:', lst.search(99))
    lst.add_after(10, 12)
    print('After add_after 10 -> 12:', lst.display())
    deleted = lst.delete_after(10)
    print('Deleted after 10:', deleted)
    print('After delete_after:', lst.display())
    head_deleted = lst.delete_at_head()
    tail_deleted = lst.delete_at_tail()
    print('Deleted head:', head_deleted)
    print('Deleted tail:', tail_deleted)
    print('Final list:', lst.display())
