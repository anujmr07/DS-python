class Node:
    def __init__(self,data):
        self.data= data
        self.next = None

class Linked_List3:
    def __init__(self):
        self.head = None

    def add_at_tail(self,data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        cur = self.head
        while cur.next is not None: 
            cur = cur.next
        cur.next = new_node
        
    def display(self):
        out =[]
        cur = self.head
        while cur is not None:
            out.append(cur.data)
            cur = cur.next
        return out
        
    def sum_of_last_n(self, n):
        if n<=0:
            raise ValueError("N must be positive number")
        
        fast = self.head
        slow = self.head
        window_sum =0
        count =0

        for _ in range(n):
            if fast is None:
                return window_sum
            window_sum += fast.data
            fast = fast.next
            count+=1
        if fast is None:
            return window_sum
        
        while fast is not None:
            window_sum = window_sum -slow.data + fast.data
            slow = slow.next
            fast = fast.next

        return window_sum
    


s = Linked_List3()
for v in [4, 5, 1, 3, 2]:
    s.add_at_tail(v)
print("List:", s.display())            # [4, 5, 1, 3, 2]
print("Sum last 3:", s.sum_of_last_n(3))  # last 3 nodes are [1,3,2] -> sum = 6
print("Sum last 10:", s.sum_of_last_n(10))# n >= length -> sum all = 15

        