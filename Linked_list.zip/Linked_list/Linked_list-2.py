class Node:
    def __init__(self,data):
        self.data = data
        self.next = None

class Linked_list2:
    def __init__(self):
        self.head = None

    def add_at_tail(self, data):
        new_node= Node(data)
        if self.head is None:
            self.head = new_node
            return
        cur = self.head
        while cur.next is not None:
            cur = cur.next
        cur.next = new_node

    def add_at_head(self,data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

    def display(self):
        element = []
        cur = self.head
        while cur is not None:
            element.append(cur.data)
            cur = cur.next 
        return element
        
def insersection(list1, list2):
    common_list = Linked_list2()

    set2 = set()
    cur = list2.head
    while cur is not None:
        set2.add(cur.data)
        cur = cur.next


    cur = list1.head
    while cur is not None:
        if cur.data in set2:
            common_list.add_at_tail(cur.data)
        cur = cur.next
    return common_list




# build first list: 3 -> 7 -> 10 -> 15
l1 = Linked_list2()              # create first list
l1.add_at_tail(3)                    # add 3
l1.add_at_tail(7)                    # add 7
l1.add_at_tail(10)                   # add 10
l1.add_at_tail(15)                   # add 15

# build second list: 8 -> 10 -> 3 -> 20
l2 = Linked_list2()              # create second list
l2.add_at_tail(8)                    # add 8
l2.add_at_tail(10)                   # add 10
l2.add_at_tail(3)                    # add 3
l2.add_at_tail(20)                   # add 20

# compute intersection (order follows list1)
common = insersection(l1, l2)        # returns list containing [3, 10]

# print lists and result
print('List1:', l1.display())        # expected: [3, 7, 10, 15]
print('List2:', l2.display())        # expected: [8, 10, 3, 20]
print('Common:', common.display())   # expected: [3, 10]  (3 appears before 10 in list1)       