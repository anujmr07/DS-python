class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class CircularSinglyLinkedList:
    def __init__(self):
        self.head = None

    def add_at_tail(self, data):
        new_node = Node(data)
        if self.head is None:
            new_node.next = new_node
            self.head = new_node
            return
        cur = self.head
        while cur.next is not self.head:
            cur = cur.next
        cur.next = new_node
        new_node.next = self.head

    def display(self):
        out = []
        if self.head is None:
            return out
        cur = self.head
        while True:
            out.append(cur.data)
            cur = cur.next
            if cur is self.head:
                break
        return out

    def remove_odds(self):
        if self.head is None:
            return
        cur = self.head
        start = self.head
        found_even = None
        while True:
            if cur.data % 2 == 0:
                found_even = cur
                break
            cur = cur.next
            if cur is start:
                break
        if found_even is None:
            self.head = None
            return
        self.head = found_even
        prev = self.head
        cur = self.head.next
        while cur is not self.head:
            if cur.data % 2 == 1:
                prev.next = cur.next
                cur = prev.next
            else:
                prev = cur
                cur = cur.next

if __name__ == "__main__":
    cl = CircularSinglyLinkedList()
    for v in [1, 2, 3, 4, 5, 6]:
        cl.add_at_tail(v)
    print("Before:", cl.display())
    cl.remove_odds()
    print("After removing odds:", cl.display())

    cl2 = CircularSinglyLinkedList()
    for v in [1, 3, 5]:
        cl2.add_at_tail(v)
    print("Before:", cl2.display())
    cl2.remove_odds()
    print("After removing odds (all removed):", cl2.display())
