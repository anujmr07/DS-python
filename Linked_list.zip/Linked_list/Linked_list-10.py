class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

def has_cycle(head):
    slow = head
    fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow is fast:
            return True
    return False

def cycle_length(head):
    slow = head
    fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow is fast:
            count = 1
            cur = slow.next
            while cur is not slow:
                count += 1
                cur = cur.next
            return count
    return 0

def find_cycle_start(head):
    slow = head
    fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow is fast:
            break
    else:
        return None
    slow = head
    while slow is not fast:
        slow = slow.next
        fast = fast.next
    return slow

# example usage
if __name__ == '__main__':
    # create list 1->2->3->4->5 and make a cycle 5->3
    a = Node(1); b = Node(2); c = Node(3); d = Node(4); e = Node(5)
    a.next = b; b.next = c; c.next = d; d.next = e; e.next = c

    print(has_cycle(a))            # True
    print(cycle_length(a))         # 3
    start = find_cycle_start(a)
    print(start.data if start else None)  # 3

    # acyclic example
    x = Node(1); y = Node(2); z = Node(3)
    x.next = y; y.next = z
    print(has_cycle(x))            # False
    print(cycle_length(x))         # 0
    print(find_cycle_start(x))     # None
